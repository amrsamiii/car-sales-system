package carapp;

import com.sun.prism.impl.PrismSettings;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class Login  {
    
    
    public abstract void log() ;
            

}